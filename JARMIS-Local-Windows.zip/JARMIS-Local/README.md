# JARMIS AI Local — protótipo funcional 0.1

Este pacote roda um assistente local no Windows com Ollama e um modelo Qwen 2.5 7B. Ele não usa créditos de IA da Floot para gerar as respostas locais. É uma primeira base de engenharia, não uma réplica completa da ficção do Homem de Ferro.

## Instalação
1. Instale o Ollama: https://ollama.com/download
2. Instale Node.js 20 ou superior: https://nodejs.org/
3. Extraia esta pasta no Windows.
4. Dê dois cliques em `start-jarmis.bat`. Na primeira execução, o script baixa `qwen2.5:7b` (vários GB).
5. Abra o endereço `http://127.0.0.1:4317/?token=...` que aparecer no terminal. Não remova nem compartilhe o token.

## O que já faz
- Conversa com modelo local através da API do Ollama.
- Mantém um histórico curto em memória durante a execução.
- Tenta usar ferramentas para consultar o sistema, abrir Calculadora/Bloco de Notas/Explorador/Edge, listar nomes de arquivos em Desktop/Documentos/Downloads e criar notas em `Documentos\JARMIS`.
- Inclui interface web local, respostas por voz via síntese do navegador e entrada por microfone quando o navegador oferece suporte.

## Limitações importantes
- O modelo precisa de recursos de hardware; desempenho varia com RAM, CPU e GPU.
- A voz masculina depende das vozes instaladas no Windows/navegador. Reconhecimento de voz pode depender de suporte do navegador e/ou serviços externos.
- Não há controle irrestrito do PC, automação universal de cliques, visão de tela, e-mail, navegação autônoma ou acesso remoto configurado.
- Por segurança, o servidor escuta apenas em `127.0.0.1` por padrão. O modo LAN não está habilitado por padrão. Não exponha a porta à internet.
- A interface local não é a mesma URL do preview Floot; o preview hospedado não consegue acessar diretamente `localhost` do seu computador.
- Ferramentas são limitadas e modelos podem gerar chamadas incorretas; confirme ações importantes.

## Diagnóstico
- Se aparecer “Ollama offline”, abra Ollama e rode `ollama list` no terminal.
- Se o modelo não estiver instalado, rode `ollama pull qwen2.5:7b`.
- Para encerrar, volte ao terminal e pressione Ctrl+C.

## Acesso pelo celular na mesma rede Wi-Fi (opcional)
1. No Windows, inicie `start-jarmis-lan.bat` em vez do script normal.
2. Use o endereço com o IP local mostrado no terminal, no celular conectado ao mesmo Wi-Fi. Mantenha a janela aberta.
3. Esse modo exige uma rede privada confiável e usa um token de acesso. Nunca encaminhe a porta do roteador nem exponha o servidor à internet. Para voz no celular, navegadores geralmente exigem HTTPS; o chat por texto é o caminho esperado neste protótipo.
