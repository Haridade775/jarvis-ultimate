import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.JARMIS_PORT || 4317);
const LAN = process.argv.includes('--lan');
const HOST = LAN ? '0.0.0.0' : '127.0.0.1';
const TOKEN = process.env.JARMIS_TOKEN || crypto.randomBytes(18).toString('hex');
const OLLAMA = process.env.OLLAMA_URL || 'http://127.0.0.1:11434';
const MODEL = process.env.JARMIS_MODEL || 'qwen2.5:7b';
const notesDir = path.join(os.homedir(), 'Documents', 'JARMIS');
const sessions = new Map();

const system = `Você é JARMIS AI, assistente pessoal local do usuário. Fale sempre em português brasileiro, com voz/persona masculina calma, objetiva e inteligente. Você está rodando localmente com acesso limitado a ferramentas. Seja honesta: nunca diga que executou algo se a ferramenta não confirmou. Peça confirmação antes de qualquer ação destrutiva ou de impacto. Não tente contornar permissões. Ferramentas permitidas: consultar hora e sistema, listar nomes de arquivos em pastas comuns, abrir aplicativos de uma lista fixa e criar notas em Documentos/JARMIS. Não existe acesso irrestrito ao computador, internet ou arquivos privados. Respostas faladas devem ser concisas.`;

const tools = [
  { type: 'function', function: { name: 'get_system_info', description: 'Consultar hora local, sistema operacional e memória aproximada.', parameters: { type: 'object', properties: {}, additionalProperties: false } } },
  { type: 'function', function: { name: 'open_app', description: 'Abrir um aplicativo aprovado do Windows.', parameters: { type: 'object', properties: { app: { type: 'string', enum: ['Bloco de Notas', 'Calculadora', 'Explorador de Arquivos', 'Microsoft Edge'] } }, required: ['app'], additionalProperties: false } } },
  { type: 'function', function: { name: 'list_user_files', description: 'Listar nomes de arquivos de uma pasta comum, sem ler o conteúdo.', parameters: { type: 'object', properties: { folder: { type: 'string', enum: ['Área de Trabalho', 'Documentos', 'Downloads'] } }, required: ['folder'], additionalProperties: false } } },
  { type: 'function', function: { name: 'create_note', description: 'Criar um arquivo de texto dentro de Documentos/JARMIS.', parameters: { type: 'object', properties: { filename: { type: 'string', description: 'Nome curto do arquivo, sem caminho e sem extensão obrigatória.' }, content: { type: 'string', description: 'Texto da nota, até 6000 caracteres.' } }, required: ['filename', 'content'], additionalProperties: false } } }
];

function runApprovedApp(app) {
  const commands = {
    'Bloco de Notas': ['notepad.exe', []],
    'Calculadora': ['calc.exe', []],
    'Explorador de Arquivos': ['explorer.exe', []],
    'Microsoft Edge': ['cmd.exe', ['/c', 'start', '', 'msedge']]
  };
  const spec = commands[app];
  if (!spec) return { ok: false, message: 'Aplicativo não permitido.' };
  try { spawn(spec[0], spec[1], { detached: true, stdio: 'ignore', windowsHide: true }).unref(); return { ok: true, message: `${app} foi solicitado para abrir.` }; }
  catch { return { ok: false, message: `Não consegui abrir ${app}.` }; }
}

async function executeTool(name, args) {
  if (name === 'get_system_info') return { ok: true, time: new Date().toLocaleString('pt-BR'), os: `${os.type()} ${os.release()}`, totalMemoryGB: Math.round(os.totalmem()/1024**3), freeMemoryGB: Math.round(os.freemem()/1024**3) };
  if (name === 'open_app') return runApprovedApp(args.app);
  if (name === 'list_user_files') {
    const folders = { 'Área de Trabalho': 'Desktop', 'Documentos': 'Documents', 'Downloads': 'Downloads' };
    const dir = path.join(os.homedir(), folders[args.folder] || 'Documents');
    try { const names = (await fs.readdir(dir, { withFileTypes: true })).slice(0, 60).map(d => `${d.isDirectory() ? '[PASTA]' : '[ARQUIVO]'} ${d.name}`); return { ok: true, folder: args.folder, items: names }; }
    catch { return { ok: false, message: `Não consegui listar ${args.folder}.` }; }
  }
  if (name === 'create_note') {
    const base = path.basename(String(args.filename || 'nota').replace(/[<>:"/\\|?*\x00-\x1F]/g, '').trim()).replace(/\.+$/,'').slice(0,70) || 'nota';
    const content = String(args.content || '').slice(0, 6000);
    await fs.mkdir(notesDir, { recursive: true });
    const file = path.join(notesDir, base.toLowerCase().endsWith('.txt') ? base : `${base}.txt`);
    await fs.writeFile(file, content, { encoding: 'utf8', flag: 'wx' }).catch(async e => { if (e.code === 'EEXIST') throw new Error('Já existe uma nota com esse nome; escolha outro nome.'); throw e; });
    return { ok: true, message: 'Nota criada.', path: file };
  }
  return { ok: false, message: 'Ferramenta desconhecida.' };
}

function send(res, status, data) { res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }); res.end(JSON.stringify(data)); }
async function readBody(req) { let raw=''; for await (const chunk of req) { raw += chunk; if (raw.length > 1_000_000) throw new Error('Corpo muito grande'); } return JSON.parse(raw || '{}'); }

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (req.method === 'GET' && url.pathname === '/api/status') {
      const auth = url.searchParams.get('token') === TOKEN || req.headers['x-jarmis-token'] === TOKEN;
      if (!auth) return send(res, 401, { ok: false, error: 'Token inválido.' });
      let ollama = false; let models = [];
      try { const r = await fetch(`${OLLAMA}/api/tags`, { signal: AbortSignal.timeout(2500) }); if (r.ok) { ollama = true; models = (await r.json()).models?.map(m => m.name) || []; } } catch {}
      return send(res, 200, { ok: true, ollama, model: MODEL, availableModels: models, mode: LAN ? 'rede local (token obrigatório)' : 'somente este computador', tools: ['status do sistema', 'abrir apps aprovados', 'listar nomes de arquivos', 'criar notas'] });
    }
    if (req.method === 'POST' && url.pathname === '/api/chat') {
      const body = await readBody(req);
      if (body.token !== TOKEN) return send(res, 401, { error: 'Token inválido.' });
      const text = String(body.message || '').trim().slice(0, 6000);
      if (!text) return send(res, 400, { error: 'Digite uma mensagem.' });
      const id = String(body.sessionId || 'default').slice(0,80);
      const history = sessions.get(id) || [];
      history.push({ role: 'user', content: text });
      const messages = [{ role: 'system', content: system }, ...history.slice(-16)];
      let reply = '';
      try {
        for (let step = 0; step < 4; step++) {
          const r = await fetch(`${OLLAMA}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ model: MODEL, messages, tools, stream: false, options: { temperature: 0.35 } }), signal: AbortSignal.timeout(180000) });
          if (!r.ok) { const t = await r.text(); throw new Error(`Ollama retornou ${r.status}: ${t.slice(0,300)}`); }
          const data = await r.json(); const msg = data.message || {}; messages.push(msg);
          if (Array.isArray(msg.tool_calls) && msg.tool_calls.length) {
            for (const call of msg.tool_calls) {
              const name = call.function?.name; const args = call.function?.arguments || {};
              let result;
              try { result = await executeTool(name, args); } catch (e) { result = { ok: false, message: e instanceof Error ? e.message : 'Erro ao executar ferramenta.' }; }
              messages.push({ role: 'tool', tool_name: name, content: JSON.stringify(result) });
            }
            continue;
          }
          reply = String(msg.content || '').trim(); break;
        }
      } catch (e) { return send(res, 502, { error: `Não consegui acessar o modelo local. Confira se o Ollama está aberto e se o modelo ${MODEL} foi baixado. Detalhe: ${e instanceof Error ? e.message : 'erro desconhecido'}` }); }
      if (!reply) reply = 'Concluí a etapa de processamento, mas não recebi uma resposta final do modelo. Tente novamente.';
      history.push({ role: 'assistant', content: reply }); sessions.set(id, history.slice(-16));
      return send(res, 200, { reply });
    }
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
      const html = await fs.readFile(path.join(ROOT, 'public', 'index.html'));
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' }); return res.end(html);
    }
    res.writeHead(404); res.end('Not found');
  } catch (e) { send(res, 500, { error: e instanceof Error ? e.message : 'Erro interno.' }); }
});
server.listen(PORT, HOST, () => {
  console.log('\n=== JARMIS AI LOCAL ===');
  console.log(`Acesse neste computador: http://127.0.0.1:${PORT}/?token=${TOKEN}`);
  if (LAN) {
    for (const [name, list] of Object.entries(os.networkInterfaces())) {
      for (const net of list || []) if (net.family === 'IPv4' && !net.internal) console.log(`Acesse na rede local (${name}): http://${net.address}:${PORT}/?token=${TOKEN}`);
    }
  }
  console.log(`Modelo: ${MODEL}`);
  console.log(`Escuta: ${HOST}:${PORT}`);
  console.log('Não compartilhe o token. Para encerrar, pressione Ctrl+C.');
  if (LAN) console.log('AVISO: modo LAN ativo; use apenas em Wi-Fi privado, nunca exponha a porta à internet. Voz no celular pode exigir HTTPS e não funcionar por HTTP.');
});
