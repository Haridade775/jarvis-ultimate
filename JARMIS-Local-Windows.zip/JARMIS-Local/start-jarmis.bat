@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo ERRO: Instale Node.js 20 ou superior em https://nodejs.org/
  pause
  exit /b 1
)
where ollama >nul 2>nul
if errorlevel 1 (
  echo ERRO: Instale Ollama em https://ollama.com/download e abra-o uma vez.
  pause
  exit /b 1
)
echo Verificando modelo local qwen2.5:7b...
ollama list | findstr /i "qwen2.5:7b" >nul
if errorlevel 1 (
  echo Baixando o modelo. Isso pode demorar e usar varios GB de internet/disco...
  ollama pull qwen2.5:7b
  if errorlevel 1 (echo Falha ao baixar o modelo. & pause & exit /b 1)
)
node server.mjs
pause
